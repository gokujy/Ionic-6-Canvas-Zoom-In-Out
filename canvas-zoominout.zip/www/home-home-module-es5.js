(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html":
    /*!***************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
      \***************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppHomeHomePageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-title>\n      Blank\n    </ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"read()\">Read</ion-button>\n      <ion-button (click)=\"toggleDrawing()\">{{ isDrawingText }}</ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content [fullscreen]=\"true\">\n  <canvas #canvasDraw (touchstart)=\"handleStart($event)\" (touchmove)=\"handleMove($event)\"\n    (touchend)=\"handleEnd($event)\"></canvas>\n  <ion-item lines=\"none\">\n    <ion-button (click)=\"plus()\" fill=\"clear\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-button>\n    <ion-button (click)=\"minus()\" fill=\"clear\">\n      <ion-icon name=\"remove\"></ion-icon>\n    </ion-button>\n  </ion-item>\n</ion-content>";
      /***/
    },

    /***/
    "./src/app/home/home-routing.module.ts":
    /*!*********************************************!*\
      !*** ./src/app/home/home-routing.module.ts ***!
      \*********************************************/

    /*! exports provided: HomePageRoutingModule */

    /***/
    function srcAppHomeHomeRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomePageRoutingModule", function () {
        return HomePageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _home_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./home.page */
      "./src/app/home/home.page.ts");

      var routes = [{
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_3__["HomePage"]
      }];

      var HomePageRoutingModule = function HomePageRoutingModule() {
        _classCallCheck(this, HomePageRoutingModule);
      };

      HomePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], HomePageRoutingModule);
      /***/
    },

    /***/
    "./src/app/home/home.module.ts":
    /*!*************************************!*\
      !*** ./src/app/home/home.module.ts ***!
      \*************************************/

    /*! exports provided: HomePageModule */

    /***/
    function srcAppHomeHomeModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomePageModule", function () {
        return HomePageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _home_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./home.page */
      "./src/app/home/home.page.ts");
      /* harmony import */


      var _home_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./home-routing.module */
      "./src/app/home/home-routing.module.ts");

      var HomePageModule = function HomePageModule() {
        _classCallCheck(this, HomePageModule);
      };

      HomePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"], _home_routing_module__WEBPACK_IMPORTED_MODULE_6__["HomePageRoutingModule"]],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_5__["HomePage"]]
      })], HomePageModule);
      /***/
    },

    /***/
    "./src/app/home/home.page.scss":
    /*!*************************************!*\
      !*** ./src/app/home/home.page.scss ***!
      \*************************************/

    /*! exports provided: default */

    /***/
    function srcAppHomeHomePageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-content {\n  height: 100%;\n  width: 100%;\n  display: block;\n}\n\ncanvas {\n  border: 1px solid darkgoldenrod;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9ob21lLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFlBQUE7RUFDQSxXQUFBO0VBQ0EsY0FBQTtBQUNGOztBQU1BO0VBQ0UsK0JBQUE7QUFIRiIsImZpbGUiOiJzcmMvYXBwL2hvbWUvaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCB7XG4gIGhlaWdodDogMTAwJTtcbiAgd2lkdGg6IDEwMCU7XG4gIGRpc3BsYXk6IGJsb2NrO1xuXG4gIC8vIC0tYmFja2dyb3VuZDogdXJsKC9hc3NldHMvaW1ncy93b3Jrc2hlZXQucG5nKSBuby1yZXBlYXQgY2VudGVyL2NvdmVyIGZpeGVkO1xuICAvLyB3aWR0aDogMTAwJTtcbiAgLy8gYmFja2dyb3VuZC1zaXplOiAxMDAlIDEwMCU7XG59XG5cbmNhbnZhcyB7XG4gIGJvcmRlcjogMXB4IHNvbGlkIGRhcmtnb2xkZW5yb2Q7XG59XG4iXX0= */";
      /***/
    },

    /***/
    "./src/app/home/home.page.ts":
    /*!***********************************!*\
      !*** ./src/app/home/home.page.ts ***!
      \***********************************/

    /*! exports provided: HomePage */

    /***/
    function srcAppHomeHomePageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomePage", function () {
        return HomePage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

      var HomePage = /*#__PURE__*/function () {
        function HomePage(platform, renderer) {
          _classCallCheck(this, HomePage);

          this.platform = platform;
          this.renderer = renderer; // drag related variables

          this.dragok = false;
          this.imageObj = new Image();
          this.scale = 1.0;
          this.scaleMultiplier = 0.8;
          this.isDrawing = false;
          this.isDrawingText = "Zoom";
          this.imageName = "/assets/imgs/background/worksheet.png";
        }

        _createClass(HomePage, [{
          key: "ngAfterViewInit",
          value: function ngAfterViewInit() {
            var _this = this;

            // canvas related variables
            this.canvasElement = this.canvas.nativeElement;
            this.canvasElement.width = this.platform.width() + '';
            this.canvasElement.height = 500;
            var canvasPosition = this.canvasElement.getBoundingClientRect();
            var ctx = this.canvasElement.getContext('2d');
            this.offsetX = canvasPosition.left;
            this.offsetY = canvasPosition.top;
            var img = new Image();
            img.src = this.imageName;

            img.onload = function () {
              ctx.drawImage(img, 0, 0, ctx.canvas.width, ctx.canvas.height);
              _this.canvasElement.backgroundImageStretch = true;
            };

            this.imageObj.src = this.imageName; // setTimeout(e => this.draw(scale, translatePos), 1000);
          }
        }, {
          key: "draw",
          value: function draw(scale, translatePos) {
            console.log(scale + " : " + translatePos); // debugger;

            var ctx = this.canvasElement.getContext('2d');

            if (!this.isDrawing) {
              ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height); // Clears the canvas

              ctx.save(); // ctx.translate(translatePos.x, translatePos.y);

              ctx.scale(scale, scale);
              ctx.drawImage(this.imageObj, translatePos.x, translatePos.y, ctx.canvas.width, ctx.canvas.height);
              ctx.restore();
            }

            this.lastX = translatePos.x;
            this.lastY = translatePos.y; // clear canvas
            // ctx.clearRect(0, 0, this.canvasElement.width, this.canvasElement.height);
            // ctx.save();
            // ctx.translate(translatePos.x, translatePos.y);
            // ctx.scale(scale, scale);
            // ctx.beginPath(); // begin custom shape
            // ctx.moveTo(-119, -20);
            // ctx.bezierCurveTo(-159, 0, -159, 50, -59, 50);
            // ctx.bezierCurveTo(-39, 80, 31, 80, 51, 50);
            // ctx.bezierCurveTo(131, 50, 131, 20, 101, 0);
            // ctx.bezierCurveTo(141, -60, 81, -70, 51, -50);
            // ctx.bezierCurveTo(31, -95, -39, -80, -39, -50);
            // ctx.bezierCurveTo(-89, -95, -139, -80, -119, -20);
            // ctx.closePath(); // complete custom shape
            // var grd = ctx.createLinearGradient(-59, -100, 81, 100);
            // grd.addColorStop(0, "#8ED6FF"); // light blue
            // grd.addColorStop(1, "#004CB3"); // dark blue
            // ctx.fillStyle = grd;
            // ctx.fill();
            // ctx.lineWidth = 5;
            // ctx.strokeStyle = "#0000ff";
            // ctx.stroke();
            // ctx.restore();
          }
        }, {
          key: "handleStart",
          value: function handleStart(e) {
            var canvasPosition = this.canvasElement.getBoundingClientRect(); // this.lastX = e.touches[0].pageX - canvasPosition.left;
            // this.lastY = e.touches[0].pageY - canvasPosition.top;

            e.preventDefault();
            this.startX = e.touches[0].clientX - this.offsetX;
            this.startY = e.touches[0].clientY - this.offsetY;
            this.lastX = e.touches[0].pageX;
            this.lastY = e.touches[0].pageY - 50;
          }
        }, {
          key: "handleMove",
          value: function handleMove(e) {
            // console.log(event);
            var canvasPosition = this.canvasElement.getBoundingClientRect();
            var ctx = this.canvasElement.getContext('2d'); // variables to save last touch position
            // used to see how far the user dragged the touch
            // and then move the text by that distance

            var currentX = e.touches[0].pageX - canvasPosition.x;
            var currentY = e.touches[0].pageY - canvasPosition.y;
            var newCurrentX = e.touches[0].pageX;
            var newCurrentY = e.touches[0].pageY - 50;
            e.preventDefault();
            this.lastX = e.touches[0].clientX - this.offsetX;
            this.lastY = e.touches[0].clientY - this.offsetY;
            var translatePos = {
              x: currentX,
              y: currentY
            }; // this.scale /= this.scaleMultiplier;

            this.draw(this.scale, translatePos);

            if (this.isDrawing) {
              ctx.beginPath();
              ctx.lineJoin = "round"; //round, bevel, miter

              ctx.lineCap = "round";
              ctx.moveTo(this.lastX, this.lastY);
              ctx.lineTo(newCurrentX, newCurrentY);
              ctx.globalCompositeOperation = "source-over";
              ctx.closePath();
              ctx.strokeStyle = "#000";
              ctx.lineWidth = 5;
              ctx.stroke();
            }
          }
        }, {
          key: "handleEnd",
          value: function handleEnd(e) {
            e.preventDefault();
          }
        }, {
          key: "plus",
          value: function plus() {
            var translatePos = {
              x: this.lastX,
              y: this.lastY
            };
            this.scale /= this.scaleMultiplier;
            this.draw(this.scale, translatePos);
          }
        }, {
          key: "minus",
          value: function minus() {
            var translatePos = {
              x: this.lastX,
              y: this.lastY
            };
            this.scale *= this.scaleMultiplier;
            this.draw(this.scale, translatePos);
          }
        }, {
          key: "toggleDrawing",
          value: function toggleDrawing() {
            this.isDrawing = !this.isDrawing;

            if (this.isDrawing) {
              this.isDrawingText = "Draw";
            } else {
              this.isDrawingText = "Zoom";
            }
          }
        }, {
          key: "read",
          value: function read() {
            alert("Move image(worksheet) for zoom in / out, This is just a testing the demo, I am still working on it. Thank you :)");
          }
        }]);

        return HomePage;
      }();

      HomePage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]
        }, {
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]
        }];
      };

      HomePage.propDecorators = {
        canvas: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"],
          args: ['canvasDraw', {
            "static": false
          }]
        }]
      };
      HomePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-home',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./home.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./home.page.scss */
        "./src/app/home/home.page.scss"))["default"]]
      })], HomePage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=home-home-module-es5.js.map