import { Component, ElementRef, Renderer2, ViewChild } from '@angular/core';
import { Platform } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  @ViewChild('canvasDraw', { static: false }) canvas: ElementRef;
  // canvas related variables
  public canvasElement: any;

  // drag related variables
  public dragok = false;

  // variables used to get touch position on the canvas
  public lastX: number;
  public lastY: number;
  public offsetX: number;
  public offsetY: number;

  // variables to save last mouse position
  // used to see how far the user dragged the mouse
  // and then move the text by that distance
  public startX: number;
  public startY: number;
  public imageName: string;
  public imageObj: any = new Image();

  public scale = 1.0;
  public scaleMultiplier = 0.8;

  public isDrawing: boolean = false;
  public isDrawingText: string = "Zoom";

  constructor(public platform: Platform,
    public renderer: Renderer2) {
    this.imageName = "/assets/imgs/background/worksheet.png";
  }

  ngAfterViewInit(): void {
    // canvas related variables
    this.canvasElement = this.canvas.nativeElement;
    this.canvasElement.width = this.platform.width() + '';
    this.canvasElement.height = 500;

    var canvasPosition = this.canvasElement.getBoundingClientRect();
    let ctx = this.canvasElement.getContext('2d');

    this.offsetX = canvasPosition.left;
    this.offsetY = canvasPosition.top;

    const img = new Image();
    img.src = this.imageName;
    img.onload = () => {
      ctx.drawImage(img, 0, 0, ctx.canvas.width, ctx.canvas.height);
      this.canvasElement.backgroundImageStretch = true;
    };

    this.imageObj.src = this.imageName;
    // setTimeout(e => this.draw(scale, translatePos), 1000);
  }

  draw(scale, translatePos) {
    console.log(scale + " : " + translatePos);
    // debugger;
    let ctx = this.canvasElement.getContext('2d');

    if (!this.isDrawing) {
      ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height); // Clears the canvas
      ctx.save();
      // ctx.translate(translatePos.x, translatePos.y);
      ctx.scale(scale, scale);
      ctx.drawImage(this.imageObj, translatePos.x, translatePos.y, ctx.canvas.width, ctx.canvas.height);
      ctx.restore();
    }

    this.lastX = translatePos.x;
    this.lastY = translatePos.y;

    // clear canvas
    // ctx.clearRect(0, 0, this.canvasElement.width, this.canvasElement.height);

    // ctx.save();
    // ctx.translate(translatePos.x, translatePos.y);
    // ctx.scale(scale, scale);
    // ctx.beginPath(); // begin custom shape
    // ctx.moveTo(-119, -20);
    // ctx.bezierCurveTo(-159, 0, -159, 50, -59, 50);
    // ctx.bezierCurveTo(-39, 80, 31, 80, 51, 50);
    // ctx.bezierCurveTo(131, 50, 131, 20, 101, 0);
    // ctx.bezierCurveTo(141, -60, 81, -70, 51, -50);
    // ctx.bezierCurveTo(31, -95, -39, -80, -39, -50);
    // ctx.bezierCurveTo(-89, -95, -139, -80, -119, -20);
    // ctx.closePath(); // complete custom shape
    // var grd = ctx.createLinearGradient(-59, -100, 81, 100);
    // grd.addColorStop(0, "#8ED6FF"); // light blue
    // grd.addColorStop(1, "#004CB3"); // dark blue
    // ctx.fillStyle = grd;
    // ctx.fill();

    // ctx.lineWidth = 5;
    // ctx.strokeStyle = "#0000ff";
    // ctx.stroke();
    // ctx.restore();
  }

  handleStart(e) {
    var canvasPosition = this.canvasElement.getBoundingClientRect();
    // this.lastX = e.touches[0].pageX - canvasPosition.left;
    // this.lastY = e.touches[0].pageY - canvasPosition.top;
    e.preventDefault();
    this.startX = e.touches[0].clientX - this.offsetX;
    this.startY = e.touches[0].clientY - this.offsetY;

    this.lastX = e.touches[0].pageX;
    this.lastY = e.touches[0].pageY - 50;
  }

  handleMove(e) {
    // console.log(event);
    var canvasPosition = this.canvasElement.getBoundingClientRect();
    let ctx = this.canvasElement.getContext('2d');
    // variables to save last touch position
    // used to see how far the user dragged the touch
    // and then move the text by that distance
    let currentX = e.touches[0].pageX - canvasPosition.x;
    let currentY = e.touches[0].pageY - canvasPosition.y;

    let newCurrentX = e.touches[0].pageX;
    let newCurrentY = e.touches[0].pageY - 50;

    e.preventDefault();
    this.lastX = e.touches[0].clientX - this.offsetX;
    this.lastY = e.touches[0].clientY - this.offsetY;

    let translatePos = {
      x: currentX,
      y: currentY
    };

    // this.scale /= this.scaleMultiplier;
    this.draw(this.scale, translatePos);

    if (this.isDrawing) {
      ctx.beginPath();
      ctx.lineJoin = "round";//round, bevel, miter
      ctx.lineCap = "round";
      ctx.moveTo(this.lastX, this.lastY);
      ctx.lineTo(newCurrentX, newCurrentY);
      ctx.globalCompositeOperation = "source-over";
      ctx.closePath();
      ctx.strokeStyle = "#000";
      ctx.lineWidth = 5;
      ctx.stroke();
    }
  }

  handleEnd(e) {
    e.preventDefault();
  }

  plus() {
    let translatePos = {
      x: this.lastX,
      y: this.lastY
    };

    this.scale /= this.scaleMultiplier;
    this.draw(this.scale, translatePos);
  }

  minus() {
    let translatePos = {
      x: this.lastX,
      y: this.lastY
    };

    this.scale *= this.scaleMultiplier;
    this.draw(this.scale, translatePos);
  }

  toggleDrawing() {
    this.isDrawing = !this.isDrawing;

    if (this.isDrawing) {
      this.isDrawingText = "Draw"
    } else {
      this.isDrawingText = "Zoom"
    }
  }

  read() {
    alert("Move image(worksheet) for zoom in / out, This is just a testing the demo, I am still working on it. Thank you :)")
  }
}
